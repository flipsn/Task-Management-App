﻿using ListManagementNew.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ListManagementNew.models
{
    public class ToDo: Item, IItem
    {
        public DateTime Deadline { get; set; }
        public bool IsCompleted { get; set; }
        public override string ToString()
        {
            return $"{Name} {Description} Completed: {IsCompleted} Deadline: {Deadline}";
        }
    }
}
