﻿using ListManagementNew.DTO;
using ListManagementNew.models;
using ListManagementNew.utilities;
using Newtonsoft.Json.Linq;
using System;

namespace ListManagementNew.utilities
{
    public class ItemJsonConverter : JsonCreationConverter<ItemDTO>
    {
        protected override ItemDTO Create(Type objectType, JObject jObject)
        {
            if (jObject == null) throw new ArgumentNullException("jObject");

            if (jObject["isCompleted"] != null || jObject["IsCompleted"] != null)
            {
                return new ToDoDTO();
            }
            else if (jObject["start"] != null || jObject["Start"] != null)
            {
                return new AppointmentDTO();
            }
            else
            {
                return new ItemDTO();
            }
        }
    }
}
