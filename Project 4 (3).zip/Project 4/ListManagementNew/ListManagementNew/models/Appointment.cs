﻿using ListManagementNew.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListManagementNew.models
{
    public class Appointment : Item
    {
        public DateTimeOffset ? Start { get; set; }
        public DateTimeOffset ? End { get; set; }
        public TimeSpan timeOnlyStart { get; set; }
        public TimeSpan timeOnlyEnd { get; set; }
        List<String> _attendees;
        public String Attendees
        {
            get
            {
                string tmp = "";
                if (_attendees != null)
                {
                    foreach (string item in _attendees)
                    {
                        tmp += item + ", ";
                    }
                }
                return tmp;
            }
            set
            {
                string[] tmp = value.Split(',');
                _attendees = tmp.ToList();

            }
        }

        public Appointment(AppointmentDTO a)
        {
            Start = a.Start;
            End = a.End;
            Start = a.Start;
            End = a.End;
            timeOnlyStart = a.timeOnlyStart;
            timeOnlyEnd = a.timeOnlyEnd;
            Priority = a.Priority;
            isNotVisible = a.isNotVisible;
            Name = a.Name;
            Description = a.Description;
            Id = a.Id;
            if (a.Attendees != null)
            {
                Attendees = a.Attendees;
            }
            else
                Attendees = "";
        }

        public Appointment()
        {
        }

        public override string ToString() 
        {
            return $"{Name} {Description} From {Start} to {End}";
        }

    }
}
