﻿using ListManagementNew.DTO;
using ListManagementNew.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ListManagementNew.models
{
    public class ToDo: Item, IItem
    {
        public DateTimeOffset ? Deadline { get; set; }
        public TimeSpan timeOnlyDeadline { get; set; } 
        public bool IsCompleted { get; set; }
        public override string ToString()
        {
            return $"{Name} {Description} Completed: {IsCompleted} Deadline: {Deadline}";
        }
        public ToDo(ToDoDTO t)
        {
            if (t != null)
            {
                Deadline = t.Deadline;
                Description = t.Description;
                IsCompleted = t.IsCompleted;
                timeOnlyDeadline = t.timeOnlyDeadline;
                Priority = t.Priority;
                Name = t.Name;
                isNotVisible = t.isNotVisible;
                Id = t.Id;
            }
        }

        public ToDo()
        {
        }
    }
}
