﻿using ListManagementNew.helpers;
using ListManagementNew.DTO;
//using ListManagementNew.utilities;
using ListManagementNew.models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ListManagementNew.utilities;
using System.Diagnostics;

namespace ListManagementNew.services
{
    public class ItemService
    {
        private ObservableCollection<ItemDTO> items;
        private ListNavigator<ItemDTO> listNav;
        private string persistencePath;
        private JsonSerializerSettings serializerSettings
            = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All };

        static private ItemService instance;

        public bool ShowComplete { get; set; }
        public ObservableCollection<ItemDTO> Items
        {
            get
            {
                var payload = JsonConvert
                    .DeserializeObject<List<ItemDTO>>(new WebRequestHandler()
                    .Get("http://localhost:60385/Item").Result);
                items.Clear();
                payload.ForEach(items.Add);
                if (String.IsNullOrEmpty(Query))
                {
                    return items;
                }
                ObservableCollection<ItemDTO> tmp = new ObservableCollection<ItemDTO>();
                foreach (var item in items)
                {
                    if (item.isNotVisible == true)
                    {
                        continue;
                    }
                    tmp.Add(item);
                }
                return tmp;
            }
        }

        public string Query { get; set; }

        public async void FilterItems()
        {
            await new WebRequestHandler().Post("http://localhost:60385/Item/Query", Query);
        }

        public async void Sort()
        {
            await new WebRequestHandler().Post("http://localhost:60385/Item/Sort", Items);
        }
        public static ItemService Current
        {
            get
            {
                if (instance == null)
                {
                    instance = new ItemService();
                }
                return instance;
            }
        }

        private ItemService()
        {
            items = new ObservableCollection<ItemDTO>();
            persistencePath = $"{Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)}\\SaveData.json";
            try
            {
                LoadFromServer();
            }
            catch (Exception)
            {
                LoadFromDisk();
            }
        }
        public void Load()
        {
            try
            {
                LoadFromServer();
            }
            catch (Exception)
            {
                LoadFromDisk();
            }
        }
        public void LoadFromServer()
        {
            var payload = JsonConvert
            .DeserializeObject<List<ItemDTO>>(new WebRequestHandler()
            .Get("http://localhost:60385/Item").Result);

            payload.ToList().ForEach(items.Add);

            //listNav = new ListNavigator<ItemDTO>(FilteredItems, 2);
        }

        public void LoadFromDisk()
        {

            if (File.Exists(persistencePath))
            {
                try
                {
                    var state = File.ReadAllText(persistencePath);
                    if (state != null)
                    {
                        items = JsonConvert
                        .DeserializeObject<ObservableCollection<ItemDTO>>(state, serializerSettings) ?? new ObservableCollection<ItemDTO>();
                    }
                }
                catch (Exception e)
                {
                    File.Delete(persistencePath);
                    items = new ObservableCollection<ItemDTO>();
                }
            }
        }
        public async Task<ItemDTO> AddOrUpdate(ItemDTO i)
        {
            if (i is ToDoDTO)
            {
                var todoStr = await new WebRequestHandler().Post("http://localhost:60385/ToDo/AddOrUpdate", i);
                return JsonConvert.DeserializeObject<ToDoDTO>(todoStr);

            }
            var apptStr = await new WebRequestHandler().Post("http://localhost:60385/Appointment/AddOrUpdate", i);
            return JsonConvert.DeserializeObject<ToDoDTO>(apptStr);
        }
        public async void Remove(ItemDTO i)
        {
            if (i is ToDoDTO)
            {
                await new WebRequestHandler().Post("http://localhost:60385/ToDo/Delete", i);
                return;
            }
            await new WebRequestHandler().Post("http://localhost:60385/Appointment/Delete", i);
            return;
        }
        public void Save()
        {
            var listJson = JsonConvert.SerializeObject(Items, serializerSettings);
            if (File.Exists(persistencePath))
            {
                File.Delete(persistencePath);
            }
            File.WriteAllText(persistencePath, listJson);
            //Saved to server by default
        }
        public Dictionary<object, ItemDTO> GetPage()
        {
            var page = listNav.GetCurrentPage();
            if (listNav.HasNextPage)
            {
                //page.Add("N", new ItemViewModel { Name = "Next" });
            }
            if (listNav.HasPreviousPage)
            {
                //page.Add("P", new Item { Name = "Previous" });
            }
            return page;
        }

        public Dictionary<object, ItemDTO> NextPage()
        {
            return listNav.GoForward();
        }

        public Dictionary<object, ItemDTO> PreviousPage()
        {
            return listNav.GoBackward();
        }

        public int NextId
        {
            get
            {
                if (Items.Any())
                {
                    return Items.Select(i => i.Id).Max() + 1;
                }
                return 1;
            }
        }
    }
}