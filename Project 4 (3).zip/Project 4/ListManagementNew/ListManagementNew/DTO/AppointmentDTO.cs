﻿using ListManagementNew.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListManagementNew.DTO
{
    public class AppointmentDTO : ItemDTO
    {
        public DateTimeOffset ? Start { get; set; }
        public DateTimeOffset ? End { get; set; }
       
        public TimeSpan timeOnlyStart { get; set; } 
        public TimeSpan timeOnlyEnd { get; set; }

        public List<string> _attendees;
        public String Attendees 
        {
            get
            { 
                string tmp = "";
                if (_attendees != null)
                {
                    foreach (string item in _attendees)
                    {
                        if (_attendees.IndexOf(item) == (_attendees.Count - 1))
                        {
                            tmp += item;
                        }
                        else
                        {
                            tmp += item + ", ";
                        }
                    }
                }
                    return tmp;
            }
            set
            {
                string[] tmp = value.Split(',').Select(i => i.Trim()).ToArray();
                _attendees = tmp.ToList();

            }
        }

        public AppointmentDTO(Item i) : base(i)
        {
            var a = i as Appointment;
            if (a != null)
            {
                Start = a.Start;
                End = a.End;
                timeOnlyStart = a.timeOnlyStart;
                timeOnlyEnd = a.timeOnlyEnd;
                Priority = a.Priority;
                isNotVisible = a.isNotVisible;
                Name = a.Name;
                Description = a.Description;
                Id = a.Id;  
                if (a.Attendees != null)
                {
                    Attendees = a.Attendees;
                }
                else
                    Attendees = "";
            }

        }
        public AppointmentDTO()
        {

        }
    }
}