﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ListManagementNew.DTO
{
    public class DeleteItemDTO
    {
        public int IdToDelete { get; set; }
    }
}
