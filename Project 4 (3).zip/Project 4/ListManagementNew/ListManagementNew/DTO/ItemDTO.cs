﻿using ListManagementNew.utilities;
using ListManagementNew.models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ListManagementNew.DTO
{
    [JsonConverter(typeof(ItemJsonConverter))]
    public class ItemDTO
    {
        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }

        }

        public string Description { get; set; }

        public int Id { get; set; }
        public string Priority
        {
            get
            {
                return priorityInt.ToString();
            }
            set
            {
                int tmp;
                int.TryParse(value, out tmp);
                if (tmp > 10)
                {
                    tmp = 10;
                }
                if (tmp < 1)
                {
                    tmp = 1;
                }
                priorityInt = tmp;
            }
        }
        public bool isNotVisible { get; set; } = true;
        public override string ToString()
        {
            return $"{Id} {Name} {Description}";
        }
        public int priorityInt;

        public ItemDTO()
        {

        }

        public ItemDTO(Item i)
        {
            Name = i.Name;
            Description = i.Description;
            Id = i.Id;
            Priority = i.Priority;
            isNotVisible = i.isNotVisible; 
        }
    }
}