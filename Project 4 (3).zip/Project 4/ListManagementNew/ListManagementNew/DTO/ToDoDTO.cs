﻿using ListManagementNew.utilities;
using ListManagementNew.models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ListManagementNew.DTO
{
    public class ToDoDTO : ItemDTO
    {
        public DateTimeOffset ? Deadline { get; set; }
        public bool IsCompleted { get; set; }
        public TimeSpan timeOnlyDeadline { get; set; }
        public ToDoDTO(Item i) : base(i)
        {
            var t = i as ToDo;
            if (t != null)
            {
                Deadline = t.Deadline;
                Description = t.Description;
                IsCompleted = t.IsCompleted;
                timeOnlyDeadline = t.timeOnlyDeadline;
                Priority = t.Priority;
                Name = t.Name;
                isNotVisible = t.isNotVisible; 
                Id = t.Id;
            }
        }

        public ToDoDTO()
        {

        }
    }
}
