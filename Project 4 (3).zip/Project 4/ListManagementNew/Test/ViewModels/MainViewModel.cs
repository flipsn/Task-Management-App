﻿using ListManagementNew.DTO;
using ListManagementNew.models;
using ListManagementNew.services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Project4.services;
using System.Diagnostics;
using System.Threading;

namespace Project4.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private ItemServiceProxy itemService = new ItemServiceProxy();
        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public event PropertyChangedEventHandler PropertyChanged;

        public MainViewModel()
        {

        }

        public ObservableCollection<ItemViewModel> Items
        {
            get
            {
                return itemService.Items; 
            }
        }
        public void FilterItems()
        {
            itemService.FilterItems();
        }
        public void Sort()
        {
            itemService.Sort();
        }
        public ItemViewModel SelectedItem
        {
            get; set;
        }

        public void AddOrUpdate(ItemViewModel item)
        {
            //Could not figure out how to wait for the item to be added/updated to the server, nor how to
            //update/ add client side instead of loading from server. Chose
            //to use this rudimentary method that may not immediately update after closing the dialog
            //in edge cases
            Task<ItemDTO> dummy = itemService.AddOrUpdate(item);
            Thread.Sleep(500);
            Refresh();
        }
        public void Refresh()
        {
            NotifyPropertyChanged("Items");
        }

        public void Delete(ItemViewModel item)
        {
            itemService.Remove(item);
            Thread.Sleep(500);
            Refresh();
        }
        public void Query(string query)
        {
            itemService.Query(query);
            Thread.Sleep(500);
        }
        public void Load()
        {
            itemService.Load();
        }
        public void LoadDisk()
        {
            itemService.LoadDisk();
        }

        public void Save()
        {
            itemService.Save();
        }
    }
}