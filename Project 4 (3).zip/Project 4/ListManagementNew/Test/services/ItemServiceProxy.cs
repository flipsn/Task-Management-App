﻿using ListManagementNew.services;
using ListManagementNew.DTO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project4.ViewModels;

namespace Project4.services
{
    public class ItemServiceProxy
    {
        private ItemService itemService;
        public ItemServiceProxy()
        {
            itemService = ItemService.Current;
        }
        public ObservableCollection<ItemViewModel> Items
        {
            get
            {
                return new ObservableCollection<ItemViewModel>
                    (itemService.Items.Select(i => new ItemViewModel(i)));
            }
        }
        public void FilterItems()
        {
            itemService.FilterItems();
        }
        public void Save()
        {
            itemService.Save();
        }
        public void Load()
        {
            itemService.Load();
        }
        public void LoadDisk()
        {
            itemService.LoadFromDisk();
        }
        public void Sort()
        {
            itemService.Sort();        
        }
        public async Task<ItemDTO> AddOrUpdate(ItemViewModel item)
        {
            return await itemService.AddOrUpdate(item.BoundItem);
        }
        public void Remove(ItemViewModel item)
        {
            itemService.Remove(item.BoundItem);
        }
        public void Query(string query)
        {
            itemService.Query = query;
        }
    }
}
