﻿using ListManagementNew.DTO;
using ListManagementNew.services;
using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using Project4.Dialogs;
using Project4.services;
using Project4.ViewModels;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using System.Threading;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Project4
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private string persistencePath = $"{Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)}\\SaveData.json";
        public MainPage()
        {
            this.InitializeComponent();
            DataContext = new MainViewModel();

        }

        private async void AddToDoClick(object sender, RoutedEventArgs e)
        {
            var dialog = new ToDoDialog(DataContext as MainViewModel);
            await dialog.ShowAsync();
        }

        private async void EditToDoClick(object sender, RoutedEventArgs e)
        {
            var dialog = new ToDoDialog(DataContext as MainViewModel);
            await dialog.ShowAsync();
        }
        private async void AddApptClick(object sender, RoutedEventArgs e)
        {
            var dialog = new AppointmentDialog(DataContext as MainViewModel);
            await dialog.ShowAsync();
        }
        private async void EditApptClick(object sender, RoutedEventArgs e)
        {
            var dialog = new AppointmentDialog(DataContext as MainViewModel);
            await dialog.ShowAsync();
        }
        private void DeleteClick(object sender, RoutedEventArgs e)
        {
            (DataContext as MainViewModel).Delete((DataContext as MainViewModel).SelectedItem);
            (DataContext as MainViewModel).Refresh();
        }

        private void SearchRequest(object sender, RoutedEventArgs e)
        {
            (DataContext as MainViewModel).Query(SearchQuery.Text);
            (DataContext as MainViewModel).Refresh();
            (DataContext as MainViewModel).FilterItems();
            Thread.Sleep(500);
            (DataContext as MainViewModel).Refresh(); 
        }

        private void SortClick(object sender, RoutedEventArgs e)
        {
            (DataContext as MainViewModel).Sort();
            //Thread.Sleep(500);
            (DataContext as MainViewModel).Refresh();
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            (DataContext as MainViewModel).Save();
        }
        private void LoadClick(object sender, RoutedEventArgs e)
        {
            (DataContext as MainViewModel).Load();
            (DataContext as MainViewModel).Refresh();
        }
    }
}
