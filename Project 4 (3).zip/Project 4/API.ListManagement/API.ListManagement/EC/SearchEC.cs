﻿using API.ListManagement.database;
using ListManagementNew.DTO;
using ListManagementNew.models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace API.ListManagement.EC
{
    public class SearchEC : Controller
    {
        public List<ItemDTO> Items { get; set; }
        public String? Query { get; set; }
        public IEnumerable<ItemDTO> FilteredItems
        {
            get
            {
                var searchResults = Items.Where(i => string.IsNullOrWhiteSpace(Query)
                //there is no query
                || (i?.Name?.ToUpper()?.Contains(Query.ToUpper()) ?? false)
                //i is any item and its name contains the query
                || (i?.Description?.ToUpper()?.Contains(Query.ToUpper()) ?? false)
                //or i is any item and its description contains the query
                || ((i as AppointmentDTO)?.Attendees?.ToUpper()?.Contains(Query.ToUpper()) ?? false));
                //or i is an appointment and has the query in the attendees list
                return searchResults;
            }
        }
        public void FilterItems()
        {
            foreach (var item in Items)
            {
                item.isNotVisible = false;
            }
            var searchResults = FilteredItems;
            int count = 0;
            foreach (var item in Items)
            {
                count = 0;
                foreach (ItemDTO item2 in searchResults)
                {
                    if (item == item2)
                    {
                        Debug.WriteLine("item match: {0}", item);
                        count++;
                    }
                    if (count == 0)
                    {
                        var tmp = Items.IndexOf(item);
                        Items.ElementAt(tmp).isNotVisible = true;
                    }

                }
            }
        }
        public void update_all_items()
        {
            FakeDatabase.filtered_items = Items;
        }
        public void Sort()
        {
            List<ItemDTO> tmp = new List<ItemDTO>();
            List<ItemDTO> tmp2 = new List<ItemDTO>();
            tmp.AddRange(new ToDoEC().Get().ToList());
            tmp.AddRange(new AppointmentEC().Get().ToList());
            foreach( var item in tmp)
            {
                tmp2.Add(item);
            }
            for(int i = 0; i < tmp.Count -1; i++)
            {
                for(int j = i +1; j < tmp.Count; j++)
                {
                    if (int.Parse(tmp[i].Priority) > int.Parse(tmp[j].Priority))
                    {
                        var tempo = tmp[i];
                        tmp[i] = tmp[j];
                        tmp[j] = tempo;
                    }
                }
            }
            Items = tmp;
            update_all_items();
        }
    }
}
