﻿using API.ListManagement.Controllers;
using API.ListManagement.database;
using ListManagementNew.DTO;
using ListManagementNew.models;
using ListManagementNew.services;
using System.Diagnostics;

namespace API.ListManagement.EC
{
    public class AppointmentEC
    {
        public IEnumerable<AppointmentDTO> Get()
        {
            return FakeDatabase.Appointments.Select(t => new AppointmentDTO(t));
        }
        public AppointmentDTO AddOrUpdate(AppointmentDTO appt)
        {
            if (appt.Id <= 0)
            {
                //CREATE
                appt.Id = ItemService.Current.NextId;
                FakeDatabase.Appointments.Add(new Appointment(appt));
                FakeDatabase.filtered_items.Add(appt);
            }
            else
            {
                //UPDATE
                var itemToUpdate = FakeDatabase.Appointments.FirstOrDefault(i => i.Id == appt.Id);
                if (itemToUpdate != null)
                {
                    var index = FakeDatabase.Appointments.IndexOf(itemToUpdate);
                    FakeDatabase.Appointments.Remove(itemToUpdate);
                    FakeDatabase.Appointments.Insert(index, new Appointment(appt));
                }
                else
                {
                    //CREATE -- Fall-Back
                    FakeDatabase.Appointments.Add(new Appointment(appt));
                }
            }

            return appt;
        }

        public AppointmentDTO Delete(AppointmentDTO appt)
        {
            var apptToDelete = FakeDatabase.Appointments.FirstOrDefault(i => i.Id == appt.Id);
            if (apptToDelete != null)
            {
                FakeDatabase.Appointments.Remove(apptToDelete);
            }

            return new AppointmentDTO(apptToDelete);
        }

    }
}
