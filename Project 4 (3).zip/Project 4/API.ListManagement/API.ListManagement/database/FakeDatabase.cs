﻿using ListManagementNew.DTO;
using ListManagementNew.models;

namespace API.ListManagement.database
{
    static public class FakeDatabase
    {

        public static List<Item> Appointments = new List<Item>
        {
            new Appointment{Name = "Appointment 1", Description="Appointment 1 Desc", Start=DateTime.Today, Id = 1},

        };

        public static List<Item> ToDos = new List<Item>
        {
            new ToDo{Name = "ToDo 1", Description="ToDo 1 Desc", IsCompleted=false, Id = 2}
        };
        public static List<ItemDTO> filtered_items = new List<ItemDTO>
        {
        };
    }
}