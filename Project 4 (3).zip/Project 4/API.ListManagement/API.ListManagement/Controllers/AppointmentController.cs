﻿using API.ListManagement.database;
using API.ListManagement.EC;
using ListManagementNew.DTO;
using Microsoft.AspNetCore.Mvc;

namespace API.ListManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AppointmentController : ControllerBase
    {
        private readonly ILogger<ToDoController> _logger;

        public AppointmentController(ILogger<ToDoController> logger)
        {
            _logger = logger;
        }

        [HttpGet()]
        public IEnumerable<AppointmentDTO> Get()
        {
            return new AppointmentEC().Get();
        }
        [HttpPost("AddOrUpdate")]
        public AppointmentDTO AddOrUpdate([FromBody] AppointmentDTO appt)
        {

            return new AppointmentEC().AddOrUpdate(appt);
        }

        [HttpPost("Delete")]
        public AppointmentDTO Delete([FromBody] AppointmentDTO deleteItemDTO)
        {
            return new AppointmentEC().Delete(deleteItemDTO);
        }
    }
}
