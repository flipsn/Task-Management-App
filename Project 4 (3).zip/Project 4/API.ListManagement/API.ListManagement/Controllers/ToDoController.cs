﻿using API.ListManagement.database;
using API.ListManagement.EC;
using ListManagementNew.DTO;
using ListManagementNew.models;
using ListManagementNew.services;
using Microsoft.AspNetCore.Mvc;

namespace API.ListManagement.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class ToDoController : ControllerBase
    {
        private readonly ILogger<ToDoController> _logger;

        public ToDoController(ILogger<ToDoController> logger)
        {
            _logger = logger;
        }

        [HttpGet()]
        public IEnumerable<ItemDTO> Get()
        {
            return new ToDoEC().Get();
        }

        [HttpPost("AddOrUpdate")]
        public ToDoDTO AddOrUpdate([FromBody] ToDoDTO todo)
        {
            return new ToDoEC().AddOrUpdate(todo);
        }

        [HttpPost("Delete")]
        public ToDoDTO Delete([FromBody] ToDoDTO deleteItemDTO)
        {
            return new ToDoEC().Delete(deleteItemDTO);
        }
    }
}
