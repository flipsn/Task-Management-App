﻿using API.ListManagement.database;
using API.ListManagement.EC;
using ListManagementNew.DTO;
using ListManagementNew.models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace API.ListManagement.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ItemController : ControllerBase
    {
        public SearchEC search = new SearchEC();
        private readonly ILogger<ToDoController> _logger;

        public ItemController(ILogger<ToDoController> logger)
        {
            _logger = logger;
        }

        [HttpGet()]
        public IEnumerable<ItemDTO> Get()
        {
            if (FakeDatabase.filtered_items.Count == 0)
            {
                List<ItemDTO> results = new List<ItemDTO>();
                results.AddRange(new ToDoEC().Get().ToList());
                results.AddRange(new AppointmentEC().Get());
                return results;
            }
            else
            {
                return FakeDatabase.filtered_items;
            }
        }
        [HttpPost("Query")]
        public void QueryContents( [FromBody] string query)
        {
            search.Query = query;
            List<ItemDTO> results = new List<ItemDTO>();
            results.AddRange(new ToDoEC().Get().ToList());
            results.AddRange(new AppointmentEC().Get());
            search.Items = results.ToList();
            search.FilterItems();
            search.update_all_items();
        }
        [HttpGet("Query")]
        public List<ItemDTO> QueryResults()
        {
            List<ItemDTO> results = new List<ItemDTO>();
            foreach(var i in FakeDatabase.filtered_items)
            {
                if(i.isNotVisible == false)
                {
                    results.Add(i);
                }
            }
            return results;
        }
        [HttpPost("Sort")]
        public void Sort()
        {
            search.Sort();
        }
    }
}
